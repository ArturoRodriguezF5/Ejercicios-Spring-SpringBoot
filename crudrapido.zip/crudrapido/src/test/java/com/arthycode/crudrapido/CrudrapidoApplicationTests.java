package com.arthycode.crudrapido;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrudrapidoApplicationTests {

	@Test
	void contextLoads() {
	}

}
