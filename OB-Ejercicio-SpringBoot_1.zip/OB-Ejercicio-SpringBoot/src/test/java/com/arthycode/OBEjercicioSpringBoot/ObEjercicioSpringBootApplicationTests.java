package com.arthycode.OBEjercicioSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ObEjercicioSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
