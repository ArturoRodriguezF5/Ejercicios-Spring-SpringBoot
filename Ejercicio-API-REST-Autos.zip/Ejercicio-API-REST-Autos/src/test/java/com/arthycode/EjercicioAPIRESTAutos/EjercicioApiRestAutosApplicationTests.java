package com.arthycode.EjercicioAPIRESTAutos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioApiRestAutosApplicationTests {

	@Test
	void contextLoads() {
	}

}
