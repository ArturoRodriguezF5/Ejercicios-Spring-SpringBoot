package com.arthycode.EjercicioAPIRESTAutos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EjercicioApiRestAutosApplication {

	public static void main(String[] args) {
		SpringApplication.run(EjercicioApiRestAutosApplication.class, args);
	}

}
