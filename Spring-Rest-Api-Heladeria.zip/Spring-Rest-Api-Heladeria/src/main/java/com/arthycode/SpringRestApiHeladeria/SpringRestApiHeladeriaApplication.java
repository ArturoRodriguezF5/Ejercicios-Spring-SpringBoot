package com.arthycode.SpringRestApiHeladeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringRestApiHeladeriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringRestApiHeladeriaApplication.class, args);
	}

}
