package com.arthycode.SpringRestApiHeladeria;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringRestApiHeladeriaApplicationTests {

	@Test
	void contextLoads() {
	}

}
