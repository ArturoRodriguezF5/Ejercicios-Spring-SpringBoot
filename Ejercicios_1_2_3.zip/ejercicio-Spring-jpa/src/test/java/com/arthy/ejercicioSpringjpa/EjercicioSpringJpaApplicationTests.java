package com.arthy.ejercicioSpringjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EjercicioSpringJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
