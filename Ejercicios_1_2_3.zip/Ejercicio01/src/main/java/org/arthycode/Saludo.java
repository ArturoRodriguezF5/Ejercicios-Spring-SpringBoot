package org.arthycode;

public class Saludo {

    public void imprimeSaludo() {
        System.out.println("Hola desde clase Saludo.");
    }
}
